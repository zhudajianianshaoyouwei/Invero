package cc.trixey.invero.builder

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject

/**
 * Invero
 * cc.trixey.invero.builder.PanelBuilder
 *
 * @author Arasple
 * @since 2023/2/20 11:35
 */
abstract class PanelBuilder : Output<JsonObject> {

    override fun output() = buildJsonObject {

    }

}