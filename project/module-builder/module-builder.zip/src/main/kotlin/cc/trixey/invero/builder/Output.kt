package cc.trixey.invero.builder

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObjectBuilder

/**
 * Invero
 * cc.trixey.invero.builder.Output
 *
 * @author Arasple
 * @since 2023/2/19 22:38
 */
interface Output<T : JsonElement> {

    fun output(): T

    fun output(body: JsonObjectBuilder, key: String) = output()?.let { body.put(key, it) }

}