package cc.trixey.invero.builder

import cc.trixey.invero.builder.util.CycleMode
import cc.trixey.invero.builder.util.asJsonArray
import cc.trixey.invero.builder.util.primi
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Invero
 * cc.trixey.invero.builder.TitleBuilder
 *
 * @author Arasple
 * @since 2023/2/19 22:37
 */
class TitleBuilder(
    var titles: MutableList<String> = mutableListOf(),
    var period: Long? = null,
    var mode: CycleMode? = null
) : Output<JsonElement> {

    override fun output(): JsonElement =
        when {
            titles.isEmpty() -> "Untitled".primi
            titles.size == 1 -> titles[0].primi
            else -> buildJsonObject {
                put("values", titles.asJsonArray())
                period?.let { put("period", period) }
                mode?.let { put("mode", mode.toString()) }
            }
        }

}