package cc.trixey.invero.builder

import cc.trixey.invero.builder.util.buildMenu

/**
 * Invero
 * cc.trixey.invero.builder.Test
 *
 * @author Arasple
 * @since 2023/2/19 22:36
 */
fun main() {

    buildMenu {
        rows = 1
    }

}