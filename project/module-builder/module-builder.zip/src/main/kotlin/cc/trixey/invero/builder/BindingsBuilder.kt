package cc.trixey.invero.builder

import cc.trixey.invero.builder.feature.CommandStructureBuilder
import cc.trixey.invero.builder.feature.ItemTraitBuilder
import cc.trixey.invero.builder.util.asJsonArray
import cc.trixey.invero.builder.util.singleOrList
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject

/**
 * Invero
 * cc.trixey.invero.builder.BindingsBuilder
 *
 * @author Arasple
 * @since 2023/2/19 22:51
 */
class BindingsBuilder(
    private val chats: MutableList<String> = mutableListOf(),
    private val items: MutableList<ItemTraitBuilder> = mutableListOf(),
    private val commands: MutableList<CommandStructureBuilder> = mutableListOf()
) : Output<JsonObject> {

    fun bindChat(vararg chats: String) =
        this.chats.addAll(chats)

    fun bindItem(material: String, block: ItemTraitBuilder.() -> Unit) =
        this.items.add(ItemTraitBuilder(material = material).also(block))

    fun bindCommand(name: String, block: CommandStructureBuilder.() -> Unit) =
        this.commands.add(CommandStructureBuilder(name = name).also(block))

    override fun output() = buildJsonObject {
        if (chats.isNotEmpty()) put("chat", chats.asJsonArray().singleOrList())
        if (items.isNotEmpty()) put("item", items.map { it.output() }.asJsonArray().singleOrList())
        if (commands.isNotEmpty()) put("command", commands.map { it.output() }.asJsonArray().singleOrList())
    }

}