package cc.trixey.invero.builder

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject

/**
 * Invero
 * cc.trixey.invero.builder.MenuBuilder
 *
 * @author Arasple
 * @since 2023/2/19 22:36
 */
class MenuBuilder internal constructor(
    val forceStandard: Boolean = false,
    internal var titleBuilder: TitleBuilder = TitleBuilder(),
    internal var bindingBuilder: BindingsBuilder = BindingsBuilder(),
    internal var nodesBuilder: NodesBuilder = NodesBuilder(),
    internal var eventsBuilder: EventsBuilder = EventsBuilder(),
    internal var tasksBuilder: TasksBuilder = TasksBuilder(),
    var type: String? = null,
    var rows: Int? = null,
    var virtual: Boolean? = null,
    var panels: MutableList<PanelBuilder> = mutableListOf()
) : Output<JsonObject> {

    override fun output() = buildJsonObject {
        put("bindings", bindingBuilder.output())
        put("nodes", nodesBuilder.output())
        put("events", eventsBuilder.output())
        put("tasks", tasksBuilder.output())

        if (panels.size > 1 || forceStandard) {
            buildJsonObject {
                put("title", titleBuilder.output())
            }
        }
    }

}