package cc.trixey.invero.builder

import kotlinx.serialization.json.JsonObject

/**
 * Invero
 * cc.trixey.invero.builder.TasksBuilder
 *
 * @author Arasple
 * @since 2023/2/20 11:32
 */
class TasksBuilder : Output<JsonObject> {

    override fun output(): JsonObject {
        TODO("Not yet implemented")
    }

}