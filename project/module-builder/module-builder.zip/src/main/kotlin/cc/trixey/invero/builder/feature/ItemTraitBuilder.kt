package cc.trixey.invero.builder.feature

import cc.trixey.invero.builder.Output
import cc.trixey.invero.builder.util.primi
import kotlinx.serialization.json.JsonPrimitive

/**
 * Invero
 * cc.trixey.invero.builder.feature.ItemTraitBuilder
 *
 * @author Arasple
 * @since 2023/2/20 10:58
 */
class ItemTraitBuilder(
    var namespace: String = "minecraft",
    var material: String,
    private val matches: MutableList<String> = mutableListOf()
) : Output<JsonPrimitive> {

    fun trait(vararg traits: String) {
        matches.addAll(traits)
    }

    override fun output() = buildString {
        append("$namespace:$material")
        matches
            .joinToString(",", prefix = "[", postfix = "]") { it }
            .let { append(it) }
    }.primi

}