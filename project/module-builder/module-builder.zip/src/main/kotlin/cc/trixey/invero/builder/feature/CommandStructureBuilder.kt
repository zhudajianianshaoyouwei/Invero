package cc.trixey.invero.builder.feature

import cc.trixey.invero.builder.Output
import cc.trixey.invero.builder.util.asJsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Invero
 * cc.trixey.invero.builder.feature.CommandStructureBuilder
 *
 * @author Arasple
 * @since 2023/2/20 10:58
 */
class CommandStructureBuilder(
    var name: String,
    var description: String? = null,
    var usage: String? = null,
    var permission: String? = null,
    var permissionMessage: String? = null,
    private val arguments: MutableList<CommandArgumentBuilder> = mutableListOf(),
    private val aliases: MutableList<String> = mutableListOf(),
) : Output<JsonElement> {

    class CommandArgumentBuilder(
        var id: String,
        var type: String? = null,
        var suggest: List<String>?,
        var restrict: Boolean = false,
        var optional: Boolean = true,
        var default: JsonPrimitive?,
        var incorrectMessage: String?
    ) : Output<JsonElement> {

        override fun output(): JsonElement {
            TODO("Not yet implemented")
        }

    }

    override fun output() =
        if (aliases.isEmpty() && arguments.isEmpty() && description == null && usage == null && permission == null && permissionMessage == null) {
            JsonPrimitive(name)
        } else {
            buildJsonObject {
                put("name", name)
                if (aliases.isNotEmpty()) put("aliases", aliases.asJsonArray())
                if (arguments.isNotEmpty()) put("arguments", arguments.map { it.output() }.asJsonArray())
                if (description != null) put("description", description)
                if (usage != null) put("usage", usage)
                if (permission != null) put("permission", permission)
                if (permissionMessage != null) put("permission-message", permissionMessage)
            }
        }

    fun aliases(vararg aliases: String) = this.aliases.addAll(aliases)

    fun argument(id: String, block: CommandArgumentBuilder.() -> Unit) =
        this.arguments.add(CommandArgumentBuilder(id, null, null, false, true, null, null).also(block))

}