package cc.trixey.invero.builder.util

import cc.trixey.invero.builder.*
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/**
 * Invero
 * cc.trixey.invero.builder.DSL
 *
 * @author Arasple
 * @since 2023/2/19 22:37
 */
fun buildMenu(block: MenuBuilder.() -> Unit) = MenuBuilder().also(block)

fun MenuBuilder.title(vararg title: String, block: TitleBuilder.() -> Unit = {}) {
    titleBuilder = TitleBuilder().apply {
        title.forEach { titles += it }
        block(this)
    }
}

fun MenuBuilder.bindings(block: BindingsBuilder.() -> Unit = {}) {
    bindingBuilder = BindingsBuilder().apply(block)
}

fun MenuBuilder.tasks(block: TasksBuilder.() -> Unit = {}) {
    tasksBuilder = TasksBuilder().apply(block)
}

fun MenuBuilder.nodes(block: NodesBuilder.() -> Unit = {}) {
    nodesBuilder = NodesBuilder().apply(block)
}

fun List<String>.asJsonArray() = map { JsonPrimitive(it) }.asJsonArray()

fun List<JsonElement>.asJsonArray() = JsonArray(this)

val Number.primi: JsonPrimitive
    get() = JsonPrimitive(this)

val String.primi: JsonPrimitive
    get() = JsonPrimitive(this)
