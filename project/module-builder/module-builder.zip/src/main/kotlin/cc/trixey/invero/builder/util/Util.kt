package cc.trixey.invero.builder.util

/**
 * Invero
 * cc.trixey.invero.builder.util.Util
 *
 * @author Arasple
 * @since 2023/2/20 11:01
 */
fun <T> Collection<*>.singleOrList(): T = (if (size == 1) first() else this) as T