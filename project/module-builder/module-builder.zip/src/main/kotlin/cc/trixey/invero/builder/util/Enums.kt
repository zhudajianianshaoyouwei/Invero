package cc.trixey.invero.builder.util

/**
 * Invero
 * cc.trixey.invero.builder.Enums
 *
 * @author Arasple
 * @since 2023/2/19 22:42
 */
enum class CycleMode {

    LOOP,

    ONE_WAY,

    REVERSABLE,

    RANDOM;

}