dependencies {
    serialization()
}