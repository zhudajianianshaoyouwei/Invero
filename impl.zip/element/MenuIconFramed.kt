package cc.trixey.invero.impl.element

import cc.trixey.invero.common.Panel

/**
 * Invero
 * cc.trixey.invero.impl.icon.IconElementFramed
 *
 * @author Arasple
 * @since 2023/1/14 21:46
 */
class MenuIconFramed(panel: Panel, key: String) : MenuIcon(key)