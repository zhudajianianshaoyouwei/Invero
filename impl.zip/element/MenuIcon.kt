package cc.trixey.invero.impl.element

/**
 * Invero
 * cc.trixey.invero.impl.icon.IconElement
 *
 * @author Arasple
 * @since 2023/1/14 21:43
 */
open class MenuIcon(val name: String, var subIconIndex: Int = -1) {

}