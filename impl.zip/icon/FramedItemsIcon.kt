package cc.trixey.invero.impl.icon

/**
 * Invero
 * cc.trixey.invero.impl.icon.FramedItemsIcon
 *
 * @author Arasple
 * @since 2023/1/15 11:49
 */
class FramedItemsIcon