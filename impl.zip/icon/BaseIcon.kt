package cc.trixey.invero.impl.icon

import cc.trixey.invero.common.panel.ElementalPanel
import cc.trixey.invero.core.action.Condition
import cc.trixey.invero.core.icon.Icon
import cc.trixey.invero.core.icon.IconHandler
import cc.trixey.invero.impl.DefaultMenuSession

/**
 * Invero
 * cc.trixey.invero.impl.icon.BaseIcon
 *
 * @author Arasple
 * @since 2023/1/15 11:38
 */
abstract class BaseIcon(
    val name: String,
    override val condition: Condition?,
    override val handler: IconHandler,
    override val updateInterval: Int,
    override val relocateInterval: Int,
    val parent: Icon? = null,
    val children: List<Icon>? = null
) : Icon {

    abstract fun create(session: DefaultMenuSession, panel: ElementalPanel)

}