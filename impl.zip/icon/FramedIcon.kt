package cc.trixey.invero.impl.icon

/**
 * Invero
 * cc.trixey.invero.impl.icon.FramedIcon
 *
 * @author Arasple
 * @since 2023/1/15 11:48
 */
class FramedIcon