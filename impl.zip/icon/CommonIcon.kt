package cc.trixey.invero.impl.icon

import cc.trixey.invero.common.panel.ElementalPanel
import cc.trixey.invero.core.action.Condition
import cc.trixey.invero.core.icon.IconHandler
import cc.trixey.invero.impl.DefaultMenuSession
import cc.trixey.invero.impl.display.DisplayCommon
import cc.trixey.invero.impl.element.MenuIcon

/**
 * Invero
 * cc.trixey.invero.impl.icon.CommonIcon
 *
 * @author Arasple
 * @since 2023/1/14 18:03
 */
class CommonIcon(
    name: String,
    condition: Condition?,
    display: DisplayCommon,
    handler: IconHandler,
    updateInterval: Int,
    relocateInterval: Int
) : BaseIcon(name, condition, display, handler, updateInterval, relocateInterval) {

    override fun create(session: DefaultMenuSession, panel: ElementalPanel) {
        val built = MenuIcon(name)

        // submit relocate task
        if (relocateInterval > 0 && !children.isNullOrEmpty() && parent == null) {
            session.launchAsync(period = relocateInterval.toLong()) {
                val previous = built.subIconIndex
                val index = children.indexOfFirst { condition!!.eval(session.context).getNow(false) }
                built.subIconIndex = index

                // render
                if (index >= 0 && previous != index) {

                }
            }
        }

        // submit update task
        if (updateInterval > 0) {
            session.launchAsync(period = updateInterval.toLong()) {

            }
        }
    }


}